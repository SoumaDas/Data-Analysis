# Exploratory Data Analysis and application of Machine learning algorithms

Exploratory Data Analaysis refers to the critical process of performing initial investigations on data so as to discover patterns,to spot anomalies,to test hypothesis and to check assumptions with the help of summary statistics and graphical representations.

In this project, I have performed Exploratory Data Analysis  on various datasets in the respective folders and applied Machine learning algorithms to predict the target variable.

Highlights:

# Mobiles Sales
This dataset comprises of all the models launched by various companies till 2021. In this dataset we have seen relation of the price and various other parameters related to a smart phone. We have visualised the market leaders in the smart phone industry.Further we have applied machine learning algorithms to predict the price of the smart phone, and also we have applied machine learning algorithm to create a model which can predict if given parameters, will the phone be a budget, mid range or a high range phone.

# Countries
I have made the dataset by siftting through various sources everything about the source is mentioned in the dataset.
