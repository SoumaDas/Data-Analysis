# Countries analysis
<a href="https://sites.google.com/ds.study.iitm.ac.in/rishavbairagya-22f3000947/activities/activity-2-world-statistics?authuser=0">Country Dataset website</a>

Detailed dataset and its sources can be found in the link above mentioned. It will redirect to a website made with google sites.